sudo apt-get install youtube-dl
chmod 777 jibutube
cp jibutube /usr/local/bin
